﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class InvestigateState : FSMState
{
	public InvestigateState(NavMeshAgent navAgent, GameObject[] zones, Player player)
	{
		playerData = player;
		stateID = FSMStateID.Investigate;
		agent = navAgent;
	}

    public override void Act()
    {
        //placeholder
    }

	public override void Enter(Transform npcTrans, Transform playerTrans)
	{
		npc = npcTrans;
		npcController = npc.GetComponent<EnemyController>();
		player = playerTrans;
        npc.GetComponent<NavMeshAgent>().SetDestination(npcController.zoneList[player.gameObject.GetComponent<Player>().zoneIndex].transform.position);
        //set new destination
    }

	public override void Reason()
	{
		if (npcController.CheckSight())
		{
			npcController.SetTransition(Transition.SawPlayer);
		}
	}
}
