﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FlashText : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        Invoke("On", 0.0f);
    }

    void On()
    {
        gameObject.SetActive(true);
        Invoke("Off", 1.0f);
    }

    void Off()
    {
        gameObject.SetActive(false);
        Invoke("On", 1.0f);
    }
}
