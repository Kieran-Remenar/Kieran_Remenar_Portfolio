﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SelfDestruct : MonoBehaviour
{
    public float despawnTime;
    // Start is called before the first frame update
    void Start()
    {
        Invoke("Despawn", despawnTime);
    }

    void Despawn()
    {
        this.gameObject.SetActive(false);
    }

    private void OnEnable()
    {
        Invoke("Despawn", despawnTime);
    }
}
