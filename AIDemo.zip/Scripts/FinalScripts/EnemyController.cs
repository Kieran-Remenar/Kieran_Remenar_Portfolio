﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;
using TMPro;

public class EnemyController : AdvancedFSM
{
    private NavMeshAgent agent;

    public Transform bulletSpawn;
	public GameObject bullet;
    public float health = 100.0f;
    public float fieldOfView = 45.0f;
    public bool spottedPlayer = false;
    public GameObject[] zoneList;


    public LineRenderer laser;
    public Renderer glass;
    public GameObject alarmText;

    //Initialize the Finite state machine for the NPC tank
    protected override void Initialize()
    {
        elapsedTime = 0.0f;

        //Get the target enemy(Player)
        GameObject objPlayer = GameObject.FindGameObjectWithTag("Player");
        playerTransform = objPlayer.transform;
        player = playerTransform.GetComponent<Player>();

        agent = GetComponent<NavMeshAgent>();

        if (!playerTransform)
            print("Player doesn't exist.. Please add one with Tag named 'Player'");

        //Start Doing the Finite State Machine
        ConstructFSM();
    }

    //Update each frame
    protected override void FSMUpdate()
    {
        elapsedTime += Time.deltaTime; //used to time bullets

        switch (CurrentStateID)
        {
            case FSMStateID.Patrol:
                laser.startColor = Color.blue;
                glass.material.SetColor("_Color", new Color(0, 0, 1, 0.0509803922f)); //blue
                break;
            case FSMStateID.Fight:
                laser.startColor = Color.red;
                glass.material.SetColor("_Color", new Color(1, 0, 0, 0.0509803922f)); //red
                break;
            case FSMStateID.Investigate:
                laser.startColor = Color.yellow;
                glass.material.SetColor("_Color", new Color(1, 1, 0, 0.0509803922f)); //yellow
                break;
        }
    }

    protected override void FSMFixedUpdate()
    {
        CurrentState.Reason();
        CurrentState.Act();
    }

    public void SetTransition(Transition t)
    {
        PerformTransition(t);
    }

    private void ConstructFSM()
    {
        //Get the list of points
        pointList = GameObject.FindGameObjectsWithTag("WandarPoint");

        Transform[] waypoints = new Transform[pointList.Length];
        int i = 0;
        foreach (GameObject obj in pointList)
        {
            waypoints[i] = obj.transform;
            i++;
        }

        PatrolState patrol = new PatrolState(agent, waypoints, player);
        patrol.AddTransition(Transition.SawPlayer, FSMStateID.Fight); //Report is included in fight
        patrol.AddTransition(Transition.ReceivedReport, FSMStateID.Investigate);

        FightState fight = new FightState(agent, waypoints, player);
        fight.AddTransition(Transition.LostPlayer, FSMStateID.Patrol); //IFF player is not seen by anyone

        InvestigateState invest = new InvestigateState(agent, zoneList, player);
        invest.AddTransition(Transition.LostPlayer, FSMStateID.Patrol);
        invest.AddTransition(Transition.SawPlayer, FSMStateID.Fight);

        AddFSMState(patrol);
        AddFSMState(fight);
        AddFSMState(invest);
    }

    public bool CheckSight()
    {
        RaycastHit hit;
        Vector3 rayDirection = playerTransform.position - transform.position;

        if (Vector3.Angle(rayDirection, transform.forward) <= fieldOfView)
        {
            if (Physics.Raycast(transform.position, rayDirection, out hit))
            {
                if (hit.collider.CompareTag("Player"))
                {
                    spottedPlayer = true;
                    return true;
                }
                else
                {
                    spottedPlayer = false;
                    return false;
                }
            }
            else
            {
                spottedPlayer = false;
                return false;
            }
        }
        else
        {
            spottedPlayer = false;
            return false;
        }
    }

    /// <summary>
    /// Alerts the enemy to the player's location
    /// </summary>
    /// <param name="index">The zone index of the player</param>
    public void Alarm(int index)
    {
        zoneIndex = index;
        alarmText.GetComponent<TextMeshProUGUI>().text = "TARGET SPOTTED IN ZONE " + (zoneIndex + 1).ToString();
        alarmText.SetActive(true);
        if (CurrentStateID != FSMStateID.Fight && CurrentStateID != FSMStateID.Investigate)
        {
            SetTransition(Transition.ReceivedReport);
        }
        else if (CurrentStateID == FSMStateID.Investigate)
        {
            GetComponent<NavMeshAgent>().SetDestination(zoneList[player.zoneIndex].transform.position);
        }
    }

    public void Shoot()
    {
		Instantiate(bullet, bulletSpawn.position, bulletSpawn.rotation);
        Debug.Log("Shoot!");
    }

    public void Die()
    {
        Destroy(this.gameObject);
    }
}
