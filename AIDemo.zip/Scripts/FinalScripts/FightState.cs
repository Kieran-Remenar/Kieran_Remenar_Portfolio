﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class FightState : FSMState
{
    float timer = 0.0f;
	float shootTimer = 0.0f;
    public float timeToForget = 3.0f;

	public FightState(NavMeshAgent navAgent, Transform[] wp, Player player)
	{
		stateID = FSMStateID.Fight;
		playerData = player;
		waypoints = wp;
		agent = navAgent;
		curRotSpeed = 2.0f;
	}

	public override void Act()
	{
		shootTimer += Time.deltaTime;
		//if player is more than x distance away, go after the player, else shoot
		if ((player.position - npc.position).magnitude > 4.0f)
		{
			npc.GetComponent<NavMeshAgent>().SetDestination(player.transform.position);
		}
		else if ((player.position - npc.position).magnitude <= 4.0)
		{
			Quaternion targetRotation = Quaternion.LookRotation(player.position - npc.position);
			npc.rotation = Quaternion.Slerp(npc.rotation, targetRotation, Time.deltaTime * curRotSpeed);
			if (shootTimer >= 2.0f)
			{
				npcController.Shoot();
				shootTimer = 0.0f;
			}
		}
    }

	public override void Enter(Transform npcTrans, Transform playerTrans)
	{
		npc = npcTrans;
		npcController = npc.GetComponent<EnemyController>();
		player = playerTrans;
        playerData.timer = 0.0f;
        npc.GetComponent<NavMeshAgent>().SetDestination(playerTrans.position);
        //npcController.spottedPlayer = true;
        player.GetComponent<Player>().visible = true;
        if (!player.GetComponent<Player>().reported) { //if player has not been reported
            player.GetComponent<Player>().RaiseAlert();
        }
		shootTimer = 0.0f;
	}

	public override void Reason()
	{
		if (!npcController.CheckSight())
		{
            timer += Time.deltaTime;
            if (timer >= timeToForget)
            {
                npcController.spottedPlayer = false;
                npcController.SetTransition(Transition.LostPlayer);
                timer = 0.0f;
            }
		} else
        {
            timer = 0.0f;
        }
	}
}
