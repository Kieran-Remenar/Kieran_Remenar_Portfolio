﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class PatrolState : FSMState
{

	public PatrolState(NavMeshAgent navAgent, Transform[] wp, Player player)
	{
		stateID = FSMStateID.Patrol;
		playerData = player;
		waypoints = wp;
		agent = navAgent;
	}

	public override void Act()
	{
		if (Vector3.Distance(npc.position, destPos) <= 3.0f)
		{ 
			//Debug.Log("Reached to the destination point\ncalculating the next point");
			FindNextPoint();
			agent.SetDestination(destPos);
		}
	}

	public override void Enter(Transform npcTrans, Transform playerTrans)
	{
		npc = npcTrans;
		npcController = npc.GetComponent<EnemyController>();
		player = playerTrans;
		FindNextPoint();
		agent.SetDestination(destPos);
	}
    //bug: THIS MAKES IT SO THAT YOU CANNOT LOSE THEM
	public override void Reason()
	{
		if (npcController.CheckSight())
        { 
			npcController.SetTransition(Transition.SawPlayer);
		}
	}
}
