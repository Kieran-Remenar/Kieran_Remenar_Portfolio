﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ButtonPress : MonoBehaviour
{
    public GameObject ButtonPromptText;
    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.CompareTag("Player"))
        {
            ButtonPromptText.SetActive(true);
        }
    }

    private void OnTriggerStay(Collider other)
    {
        if (Input.GetKeyDown("e") && other.gameObject.CompareTag("Player"))
        {
            GetComponent<Animator>().SetTrigger("Press");
            if (!GetComponent<AudioSource>().isPlaying)
            {
                GetComponent<AudioSource>().Play();
            }
            ButtonPromptText.SetActive(false);
            Invoke("Increment", 2.0f);
        }
    }

    private void OnTriggerExit(Collider other)
    {
        if (other.gameObject.CompareTag("Player"))
        {
            ButtonPromptText.SetActive(false);
        }
    }

    void Increment()
    {
        GameObject.FindGameObjectWithTag("Player").GetComponent<Player>().incrementButton();
        Destroy(gameObject);
    }

}
