﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class Player : MonoBehaviour
{
	public int zoneIndex;

    public bool visible = false;
    public int health;
    private int totalHealth;

    public bool search = false;//whether or not people are searching in a zone
    public bool reported = false; //whether or not everyone is after you
    public GameObject[] enemies;
    public EnemyController[] enemyControllers;

    public float timer;
    public float timeToForget = 3.0f;

    public int totalButtons;
    public int buttonsPressed = 0;

    public GameObject WinOverlay;
	public GameObject DeathOverlay;
    public Image healthBar;

    void Start()
    {
        totalButtons = GameObject.FindGameObjectsWithTag("Button").Length;
        enemies = GameObject.FindGameObjectsWithTag("Enemy");
        enemyControllers = new EnemyController[enemies.Length];
        int i = 0;
        foreach (GameObject enemy in enemies)
        {
            enemyControllers[i] = enemies[i].GetComponent<EnemyController>();
            i++;
        }
        totalHealth = health;
    }

    public void incrementButton()
    {
        buttonsPressed++;
        if (buttonsPressed >= totalButtons)
        {
            //TRIGGER WIN
            Instantiate(WinOverlay, GameObject.Find("Canvas").transform);
            foreach (GameObject enemy in enemies)
            {
                Destroy(enemy);
            }
            Invoke("Restart", 5.0f);
        }
    }

    void Restart()
    {
        SceneManager.LoadScene(SceneManager.GetSceneByBuildIndex(0).name);
    }

	public void UpdateZone(int index)
	{
		zoneIndex = index;
	}

	/// <summary>
	/// Tells all enemy NPCs in which zone the player was seen
	/// </summary>
	public void RaiseAlert()
	{
		foreach (EnemyController enemy in enemyControllers)
		{
			enemy.Alarm(zoneIndex);
		}
        reported = true;
	}

	public void VisibilityChange() //any time LostPlayer or SawPlayer transition happens call this
    {
        foreach (EnemyController enemy in enemyControllers)
        {
            if (enemy.spottedPlayer)
            {
                visible = true;
                return;
            }
        }
        visible = false;
        reported = false;
        enemyControllers[0].alarmText.SetActive(false);
        return;
    }

	public void TakeDamage(int damage)
	{
		health -= damage;
        healthBar.fillAmount = Mathf.Clamp01((float)health / (float)totalHealth);

		if (health <= 0)
		{
			Instantiate(DeathOverlay, GameObject.Find("Canvas").transform);
			Destroy(GetComponent<UnityStandardAssets.Characters.FirstPerson.FirstPersonController>());
			Invoke("Restart", 5.0f);
		}
	}
}
