using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class GameManager : MonoBehaviour 
{
    public float gameSpeed = 1.0f;

    private int enemies;

    private List<int> retreatProb = new List<int>() { 0, 1, 1, 1}; //default 1 in 4 chance to retreat

	// Use this for initialization
	void Start () 
    {
	    //Set the gravity Settings
        Physics.gravity = new Vector3(0, -500.0f, 0);

        //populate initial array of probabilities to retreat
        enemies = GameObject.FindGameObjectsWithTag("Enemy").Length;
        if (enemies > 4) //if there are more than 4 enemy tanks
        { //then we want to decrease the initial probability to retreat
            for (int i = 0; i < enemies - 4; i++)
            { //so we add an additional "attack" chance (1) per additional enemy
                retreatProb.Add(1);
            }
        }

    }
	
	// Update is called once per frame
	void Update () 
    {
        Time.timeScale = gameSpeed;
	}

	/// <summary>
	/// Adds a 0 to the retreat probability list, increasing the chance to run away
	/// </summary>
    public void recalcRetreatProb ()
    {
		float num0 = 0.0f;
        retreatProb.Add(0);
		foreach (int num in retreatProb)
		{
			if (num == 0)
				num0++;
		}
        Debug.Log("Probability of retreating: " + ((num0 / retreatProb.Count) * 100).ToString());
    }

	/// <summary>
	/// Runs probability for the tank to retreat
	/// </summary>
	/// <returns>Whether the tank retreats(true) or chases(false)</returns>
	public bool getRetreatProb()
	{
		int randIndex = Random.Range(0, retreatProb.Count);
		if (retreatProb[randIndex] == 0)
			return true;
		else
			return false;
	}
}
